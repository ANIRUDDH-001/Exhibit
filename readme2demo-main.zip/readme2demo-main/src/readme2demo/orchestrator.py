"""Pipeline orchestrator: explicit state machine over the stages in manifest.STAGES.

Each stage is idempotent, reads/writes the run directory, and records its
transition in manifest.json — so ``resume`` picks up exactly where a run
stopped, and ``resume --from-stage`` re-runs only downstream stages.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Optional

from rich.console import Console
from rich.markup import escape

from readme2demo import distill as distill_mod
from readme2demo import ingest as ingest_mod
from readme2demo import normalize as normalize_mod
from readme2demo import produce as produce_mod
from readme2demo import render as render_mod
from readme2demo import tutorial as tutorial_mod
from readme2demo import verify as verify_mod
from readme2demo.agent import run_agent
from readme2demo.config import Config
from readme2demo.engines import get_engine
from readme2demo.manifest import Manifest, stage_duration, new_run_id
from readme2demo.types import CommandLog, DistillOutput, Plan, TutorialOutline

console = Console()


class PipelineError(RuntimeError):
    """A stage failed in a way the orchestrator cannot recover from."""


class Orchestrator:
    def __init__(self, run_dir: Path, cfg: Config, manifest: Manifest):
        self.run_dir = run_dir
        self.cfg = cfg
        self.manifest = manifest
        self._distill_output: Optional[DistillOutput] = None

    # -- constructors ---------------------------------------------------------

    @classmethod
    def new_run(cls, repo_url: Optional[str], cfg: Config) -> "Orchestrator":
        # repo_url is optional: a guide-only run (``-s`` with no repo) passes
        # None/"". The run-id slug then falls back to the guide's file stem.
        repo_url = repo_url or ""
        fallback = cfg.step_by_step.stem if cfg.step_by_step else "guide"
        # Absolute: docker -v mounts and VHS renders need real host paths.
        run_dir = (cfg.runs_dir / new_run_id(repo_url, fallback=fallback)).resolve()
        manifest = Manifest.create(run_dir, repo_url, cfg.engine, cfg.base_image)
        return cls(run_dir, cfg, manifest)

    @classmethod
    def resume(cls, run_dir: Path, cfg: Config,
               from_stage: Optional[str] = None) -> "Orchestrator":
        run_dir = run_dir.resolve()
        manifest = Manifest.load(run_dir)
        if from_stage:
            manifest.reset_from(from_stage)
        return cls(run_dir, cfg, manifest)

    # -- artifact accessors (lazy-loaded from the run dir) --------------------

    def _plan(self) -> Plan:
        return Plan.model_validate_json((self.run_dir / "plan.json").read_text())

    def _log(self) -> CommandLog:
        return CommandLog.model_validate_json(
            (self.run_dir / "command_log.json").read_text()
        )

    def _outline(self) -> TutorialOutline:
        return TutorialOutline.model_validate_json(
            (self.run_dir / "tutorial_outline.json").read_text()
        )

    def _readme_text(self) -> str:
        repo = self.run_dir / "repo"
        for candidate in sorted(repo.glob("README*")):
            try:
                return candidate.read_text(errors="replace")[:8192]
            except OSError:
                continue
        return ""

    # -- stages ----------------------------------------------------------------

    def _stage_ingest(self) -> None:
        plan, sha, cost = ingest_mod.ingest(
            self.manifest.repo_url, self.run_dir, self.cfg.model,
            guide_file=self.cfg.step_by_step,
        )
        self.manifest.commit_sha = sha
        self.manifest.stage_complete("ingest", cost_usd=cost, feasible=plan.feasible)
        if not plan.feasible:
            for s in ("agent", "normalize", "distill", "verify", "render", "tutorial"):
                self.manifest.stage_skip(s, reason="plan marked infeasible")
            raise PipelineError(
                "Planner marked this repo infeasible: "
                + ("; ".join(plan.blockers) or plan.reasoning or "no reason given")
            )

    def _stage_agent(self) -> None:
        engine = get_engine(self.cfg.engine)
        run_agent(self.run_dir, self._plan(), engine, self.cfg)
        self.manifest.stage_complete("agent")

    def _stage_normalize(self) -> None:
        engine = get_engine(self.cfg.engine)
        log = normalize_mod.normalize(
            self.run_dir / "transcript.ndjson", engine, self.run_dir
        )
        adjusted = None
        plan = self._plan()
        plan_dirty = False
        if log.adjusted_success_command:
            # The agent swapped the planned success command for one that works
            # without infrastructure missing in the sandbox (ADJUSTED_SUCCESS
            # marker). Persist it into plan.json so distill/verify/tutorial
            # all use the command that was actually proven.
            plan.success_criteria.command = log.adjusted_success_command
            plan.success_criteria.expected_pattern = log.adjusted_success_pattern
            plan.success_criteria.description += " (adjusted by agent — see FIX notes)"
            adjusted = log.adjusted_success_command
            plan_dirty = True
            # escape(): shell commands often contain [ -f x ]-style brackets
            # that Rich would parse as markup and swallow.
            console.print(
                f"[yellow]Success command adjusted by agent:[/] {escape(adjusted)}"
            )
        # Reality-check the (LLM-authored) expected pattern against captured
        # output — a wrong pattern would fail the verify of a working build.
        pattern_changed, reason = normalize_mod.validate_success_pattern(plan, log)
        if pattern_changed:
            plan_dirty = True
            # escape(): the reason quotes regexes ([0-9]+ etc.) — see above.
            console.print(f"[yellow]Success pattern corrected:[/] {escape(reason)}")
        # Findings tools: a nonzero-exit demo command whose output matches the
        # expected pattern IS the success — mark it and persist so grounding,
        # the tape, and output lookups all see it.
        marked = normalize_mod.mark_findings_success(plan, log)
        if marked:
            (self.run_dir / "command_log.json").write_text(
                log.model_dump_json(indent=2)
            )
            console.print(
                f"[dim]{marked} findings-tool command(s) reclassified as "
                "successful (nonzero exit + expected pattern matched)[/]"
            )
        # Reality-check the SPELLING of the success command. The planner guessed
        # it at ingest, before anything ran; the assertion must execute the form
        # the sandbox actually accepted (absolute exe path, python3, an added
        # --break-system-packages) or verify fails a run whose criterion really
        # passed (failure class 17). Ordered AFTER mark_findings_success on
        # purpose: findings entries exit nonzero ON SUCCESS and only become
        # proof once that pass has marked them, so running earlier would leave
        # the reconciler blind to exactly the commands classes 4 and 13 cover.
        cmd_changed, cmd_reason = normalize_mod.reconcile_success_command(plan, log)
        if cmd_changed:
            plan_dirty = True
            # escape(): the reason quotes shell commands ([ -f x ]) — see above.
            console.print(f"[yellow]Success command corrected:[/] {escape(cmd_reason)}")
        if plan_dirty:
            (self.run_dir / "plan.json").write_text(plan.model_dump_json(indent=2))
        # Agent-cheat detection: edits to repo source can't survive the
        # pristine-clone replay (prompt rule 6). Surface it NOW, not as a
        # mysterious verify failure later.
        edited = normalize_mod.repo_files_edited(log, self.run_dir / "repo")
        if edited:
            console.print(
                "[red]⚠ Agent modified repo source files (verification will "
                "not reproduce this):[/] " + escape(", ".join(edited[:5]))
            )
        # Guide mode: every step must at least have been ATTEMPTED. An
        # unattempted step can never be grounded, so it silently vanishes from
        # the video — surface the gap here instead.
        unattempted: list[str] = []
        if plan.guide_path:
            guide_file = self.run_dir / "repo" / plan.guide_path
            if guide_file.is_file():
                from readme2demo.distill import normalize_cmd, parse_guide_steps

                attempted = {normalize_cmd(e.cmd) for e in log.entries}
                attempted |= {
                    a.split("|", 1)[0].strip() for a in attempted if "|" in a
                }
                for _, cmd in parse_guide_steps(
                    guide_file.read_text(encoding="utf-8", errors="replace")
                ):
                    norm = normalize_cmd(cmd)
                    if norm not in attempted and not norm.startswith(
                        ("cd ", "git clone")
                    ):
                        unattempted.append(cmd)
                if unattempted:
                    console.print(
                        f"[red]⚠ Agent never attempted {len(unattempted)} guide "
                        "step(s) — they cannot appear in the video:[/]"
                    )
                    for c in unattempted:
                        console.print(f"[red]    {escape(c[:100])}[/]")
        cost = log.result.cost_usd or 0.0
        self.manifest.stage_complete(
            "normalize",
            cost_usd=cost,
            outcome=log.result.outcome,
            commands=len(log.entries),
            adjusted_success=adjusted,
            source_modified=edited or None,
            guide_steps_unattempted=unattempted or None,
        )
        if log.result.outcome == "blocked":
            for s in ("distill", "verify", "render", "tutorial"):
                self.manifest.stage_skip(s, reason=log.result.blocked_reason or "blocked")
            raise PipelineError(f"Agent blocked: {log.result.blocked_reason}")
        if log.result.outcome == "failed":
            raise PipelineError(
                "Agent run failed (max turns / timeout). "
                "Inspect transcript.ndjson; retry with a higher --max-turns."
            )
        if self.cfg.budget_usd and cost > self.cfg.budget_usd:
            raise PipelineError(
                f"Agent cost ${cost:.2f} exceeded budget ${self.cfg.budget_usd:.2f}. "
                "Raise budget_usd in readme2demo.toml (or --budget-usd on a fresh run), "
                "then resume this run — the agent work is already saved."
            )

    def _stage_distill(self, feedback: str = "") -> None:
        out, cost = distill_mod.distill(
            self._plan(), self._log(), self._readme_text(),
            self.run_dir, self.cfg.model, self.manifest.repo_url,
            feedback=feedback,
        )
        self._distill_output = out
        self.manifest.stage_complete("distill", cost_usd=cost)

    def _stage_verify(self) -> None:
        plan = self._plan()
        report = verify_mod.run_verify(self.run_dir, plan, self.cfg)
        attempts_left = self.cfg.distill_retries
        if not report.passed and self.manifest.stages["normalize"].meta.get(
            "source_modified"
        ):
            # The distiller cannot fix this class of failure: the agent's
            # success depended on source patches that don't exist in the
            # pristine clone. Don't burn an LLM call pretending otherwise.
            attempts_left = 0
            console.print(
                "[red]Verify failed and the agent had modified repo source — "
                "skipping the distiller retry (it cannot help). The success "
                "path must work on the repo AS PUBLISHED; re-run the agent "
                "stage with: readme2demo resume <run> --from-stage agent[/]"
            )
        while not report.passed and attempts_left > 0:
            attempts_left -= 1
            console.print("[yellow]Verify failed — feeding log back to distiller[/]")
            feedback = verify_mod.verify_feedback(self.run_dir)
            self.manifest.stages["distill"].status = "pending"
            self.manifest.save()
            self.manifest.stage_start("distill")
            self._stage_distill(feedback=feedback)
            report = verify_mod.run_verify(self.run_dir, plan, self.cfg)
        self.manifest.verified = report.passed
        if report.passed:
            self.manifest.stage_complete(
                "verify", attempts=report.attempts, exit_code=report.exit_code
            )
        else:
            # Not fatal: artifacts ship clearly labeled UNVERIFIED.
            self.manifest.stage_complete(
                "verify", attempts=report.attempts,
                exit_code=report.exit_code, passed=False,
            )
            console.print(
                "[red]Replay did not pass — outputs will be labeled UNVERIFIED[/]"
            )

    def _stage_render(self) -> None:
        if self.cfg.skip_video:
            self.manifest.stage_skip("render", reason="--skip-video")
            return
        if not self.manifest.verified:
            # A demo video of an unverified script would be misleading (and
            # its commands likely fail on camera). Tutorial still ships,
            # loudly labeled UNVERIFIED.
            self.manifest.stage_skip("render", reason="replay unverified — no video")
            return
        # Build the tape from the FINALIZED step_by_step.md (written by the
        # tutorial stage) so the video provably follows the published guide.
        out = self._distill_output
        fallback = out.tape if out else []
        coverage = distill_mod.build_tape_from_step_by_step(
            self.run_dir, self._log(), self.manifest.repo_url, fallback
        )
        render_mod.run_render(self.run_dir, self.cfg)
        artifacts = render_mod.validate_outputs(self.run_dir)
        self.manifest.stage_complete(
            "render",
            artifacts=[p.name for p in artifacts],
            tape_coverage=f"{coverage['tape_steps']}/{coverage['guide_steps']} guide steps",
        )

    # -- post-render outputs ----------------------------------------------------

    def _produce_formats(self) -> None:
        """Dispatch the extra ``--formats`` outputs after the render stage (#230).

        Runs on BOTH render paths — rendered and skipped — because the formats
        gate is ``manifest.verified``, not whether a video was filmed, and an
        unverified run must record *why* its extra formats were skipped.

        Wrapped end to end: an optional output may never fail the run, so even a
        failure outside a builder (a manifest write, a broken registry entry)
        degrades to a printed warning. The four protected artifacts are already
        on disk and produce() fingerprints them; nothing here can promote an
        extra format into the grounding path.
        """
        try:
            results = produce_mod.produce(self.run_dir, self.manifest, self.cfg)
        except Exception as e:  # noqa: BLE001 — extra formats are never load-bearing
            console.print(
                "[yellow]Extra formats skipped: "
                f"{escape(f'{type(e).__name__}: {e}')}[/]"
            )
            return
        for name, status in results.items():
            style = "dim" if status == produce_mod.PRODUCED else "yellow"
            # escape(): builder errors carry arbitrary text (paths, shell
            # output, regexes) that Rich would otherwise parse as markup.
            console.print(f"[{style}]format {escape(name)}: {escape(status)}[/]")

    def _stage_tutorial(self) -> None:
        # Badge first: its verdict comes from manifest.verified alone (set
        # only by the verify stage), so it needs nothing from the LLM polish
        # pass — a TutorialError mid-stage must not be able to suppress it.
        tutorial_mod.write_badge_json(self.run_dir, self.manifest)
        plan = self._plan()
        cost = tutorial_mod.run_tutorial(
            self.run_dir,
            plan,
            self._log(),
            self._outline(),
            self.cfg.model,
            verified=self.manifest.verified,
            base_image=self.cfg.base_image,
            commit_sha=self.manifest.commit_sha,
            # Repo already ships its own guide → don't generate a rival one.
            generate_step_by_step=plan.guide_path is None,
            repo_url=self.manifest.repo_url,
        )
        self.manifest.stage_complete(
            "tutorial",
            cost_usd=cost,
            step_by_step="generated" if plan.guide_path is None else "repo-provided",
        )

    # -- driver ----------------------------------------------------------------

    def run(self) -> Manifest:
        handlers: dict[str, Callable[[], None]] = {
            "ingest": self._stage_ingest,
            "agent": self._stage_agent,
            "normalize": self._stage_normalize,
            "distill": self._stage_distill,
            "verify": self._stage_verify,
            "render": self._stage_render,
            "tutorial": self._stage_tutorial,
        }
        while (stage := self.manifest.next_stage()) is not None:
            console.print(f"[bold cyan]▶ {stage}[/] ({escape(self.run_dir.name)})")
            self.manifest.stage_start(stage)
            try:
                handlers[stage]()
            except PipelineError as e:
                # Spend already incurred before the raise (e.g. the distiller's
                # paid grounding retry) rides on the exception — see #103.
                self.manifest.stage_fail(
                    stage, str(e), cost_usd=getattr(e, "cost_usd", 0.0)
                )
                raise
            except Exception as e:  # noqa: BLE001 — record, then re-raise
                self.manifest.stage_fail(
                    stage,
                    f"{type(e).__name__}: {e}",
                    cost_usd=getattr(e, "cost_usd", 0.0),
                )
                raise

            # Extra output formats hang off the END of render — after the
            # protected artifacts exist and after the verified verdict is
            # final. Deliberately OUTSIDE the try above: produce() must never
            # be able to fail the render stage (#230).
            if stage == "render":
                self._produce_formats()

            # --dry-run: the feasibility verdict and blockers are known once
            # ingest completes; stop before any agent cost is spent and mark
            # the remaining stages skipped with a clear reason.
            if stage == "ingest" and self.cfg.dry_run:
                console.print(
                    "\n[bold yellow]ℹ Dry run: stopping after ingest/planning.[/]"
                )
                for s in ("agent", "normalize", "distill", "verify", "render", "tutorial"):
                    if self.manifest.stages[s].status != "completed":
                        self.manifest.stage_skip(s, reason="dry-run stop")
                break

        return self.manifest


def summarize(manifest: Manifest) -> str:
    """Human-readable run report for ``readme2demo report``."""
    repo_line = (
        f"{manifest.repo_url} @ {(manifest.commit_sha or '?')[:7]}"
        if manifest.repo_url
        else "(guide-only run — no repository)"
    )
    lines = [
        f"run:      {manifest.run_id}",
        f"repo:     {repo_line}",
        f"engine:   {manifest.engine}",
        f"verified: {'yes' if manifest.verified else 'NO'}",
        f"cost:     ${manifest.total_cost_usd:.4f}",
        "stages:",
    ]
    for name, rec in manifest.stages.items():
        duration = _format_stage_duration(stage_duration(rec))
        extra = f" — {rec.error}" if rec.error else ""
        meta = ""
        if rec.meta:
            meta = " " + json.dumps(rec.meta, default=str)
        lines.append(f"  {name:<10} {rec.status:<10} {duration:>8}{meta}{extra}")
    return "\n".join(lines)


def _format_stage_duration(seconds: float | None) -> str:
    """Render a stage duration for human and Markdown report output."""
    if seconds is None:
        return "—"
    if seconds < 1:
        return "<1s"
    minutes, remainder = divmod(round(seconds), 60)
    return f"{minutes}m {remainder}s" if minutes else f"{remainder}s"


def _md_cell(text: str) -> str:
    """Escape arbitrary text for a single GFM table cell.

    Stage errors carry raw shell output: ``|`` would split the cell and a
    newline would end the row, so pipes are backslash-escaped and newlines
    collapsed to spaces.
    """
    return " ".join(text.splitlines()).replace("|", "\\|")


def summarize_markdown(manifest: Manifest, artifacts: list[str]) -> str:
    """GitHub-flavored Markdown run summary for ``readme2demo report --markdown``.

    Pure: renders only the manifest plus ``artifacts``, a pre-computed list of
    artifact filenames present in the run dir (the CLI does the ``exists()``
    checks). Emitted for piping into ``$GITHUB_STEP_SUMMARY``.

    The Verified badge derives from ``manifest.verified`` and nothing else —
    that flag is set only by the fresh-container replay in the verify stage,
    and this summary must not soften, infer, or upgrade it.
    """
    repo_part = (
        f"`{manifest.repo_url}` @ `{(manifest.commit_sha or '?')[:7]}`"
        if manifest.repo_url
        else "(guide-only run — no repository)"
    )
    badge = "**Verified: yes**" if manifest.verified else "**Verified: NO**"
    lines = [
        f"## readme2demo — {manifest.run_id}",
        "",
        f"{badge} — {repo_part} — engine `{manifest.engine}` — "
        f"total cost ${manifest.total_cost_usd:.4f}",
        "",
        "| Stage | Status | Duration | Cost (USD) | Notes |",
        "|---|---|---|---|---|",
    ]
    for name, rec in manifest.stages.items():
        # Failed stages carry `error`; skipped stages carry meta["reason"].
        note = rec.error or rec.meta.get("reason", "")
        lines.append(
            f"| {name} | {rec.status} | {_format_stage_duration(stage_duration(rec))} | "
            f"{rec.cost_usd:.4f} | {_md_cell(note)} |"
        )
    if artifacts:
        lines += ["", "**Artifacts**", ""]
        lines += [f"- {name}" for name in artifacts]
    return "\n".join(lines)
