"""Tests for produce(): post-render dispatch of extra output formats (#230).

No docker, no network, no API — every stage and every format builder is
monkeypatched (the pattern in tests/test_orchestrator.py). The promo builder
(#170) is exercised the same way: its LLM pass and its ffmpeg compositor are
both replaced, so this file stays in the sub-second suite.
"""

import json
from pathlib import Path

import pytest

from readme2demo import produce as produce_mod
from readme2demo import promo as promo_mod
from readme2demo import promo_script as promo_script_mod
from readme2demo.config import Config
from readme2demo.manifest import Manifest
from readme2demo.orchestrator import Orchestrator
from readme2demo.produce import (
    PRODUCED,
    PROMO_FORMAT,
    PROMO_INPUTS,
    PROTECTED_ARTIFACTS,
    build_promo,
    builder_for,
    produce,
    requested_formats,
)
from readme2demo.promo_script import PromoScriptError
from readme2demo.types import (
    AgentResult,
    CommandEntry,
    CommandLog,
    Plan,
    PromoScene,
    PromoScript,
    SuccessCriteria,
)

_URL = "https://github.com/x/y"


# -- helpers -------------------------------------------------------------------


def make_manifest(tmp_path: Path, *, verified: bool = True, name: str = "run") -> Manifest:
    m = Manifest.create(tmp_path / name, _URL, "claude-code", "img")
    m.verified = verified
    m.save()
    return m


def cfg_with_formats(*names: str, **kwargs) -> Config:
    """A Config carrying a ``formats`` selection.

    Built with ``model_copy(update=...)`` rather than ``Config(formats=[...])``
    because the field itself arrives with #212 and ``Config`` is
    ``extra="forbid"`` — this helper works both before and after that lands,
    which is exactly the degradation produce() itself has to survive.
    """
    return Config(**kwargs).model_copy(update={"formats": list(names)})


def seed_protected(run_dir: Path, *, skip: tuple[str, ...] = ()) -> dict[str, bytes]:
    """Write the four protected artifacts with known bytes; return them."""
    written: dict[str, bytes] = {}
    for name in PROTECTED_ARTIFACTS:
        if name in skip:
            continue
        data = f"{name} contents\n".encode()
        (run_dir / name).write_bytes(data)
        written[name] = data
    return written


# -- format selection ----------------------------------------------------------


def test_requested_formats_normalizes_case_dedupes_and_keeps_order():
    cfg = cfg_with_formats("GIF", "demo", " gif ", "promo")
    assert requested_formats(cfg) == ["gif", "demo", "promo"]


def test_registry_implemented_flag_agrees_with_the_builder_table():
    """Regression (#230/#170): a format the CLI accepts must have a builder,
    and a format with a builder must be accepted by the CLI.

    These are two separate tables — formats.FORMATS gates the --formats flag,
    produce's registry resolves the builder — and they drifted: the promo
    builder was wired while FORMATS still said implemented=False, so
    `--formats promo` was rejected before produce() ever ran. Neither side's
    own tests could see it.
    """
    from readme2demo.formats import FORMATS
    from readme2demo.produce import RENDER_STAGE_FORMATS

    for name, spec in FORMATS.items():
        if name in RENDER_STAGE_FORMATS:
            continue  # render owns these; produce never dispatches them
        has_builder = builder_for(name) is not None
        assert spec.implemented == has_builder, (
            f"{name}: FORMATS says implemented={spec.implemented} but "
            f"builder_for({name!r}) returned {'a builder' if has_builder else 'None'}"
        )


def test_requested_formats_defaults_to_the_render_stage_set():
    """Regression (#230): a default config leaves produce() nothing to dispatch.

    #212 landed ``Config.formats`` defaulting to today's exact output set —
    both formats the render stage owns — so an untouched config reaches
    produce() with nothing left to do. This previously pinned a getattr
    bridge for "before #212 lands"; the bridge is retired, the guarantee is
    not.
    """
    assert Config().formats == ["demo", "gif"]
    assert requested_formats(Config()) == ["demo", "gif"]


def test_requested_formats_empty_selection_falls_back():
    """Regression (#230): an explicitly emptied selection resolves to the
    render-stage set rather than silently dispatching nothing."""
    assert requested_formats(cfg_with_formats()) == ["demo", "gif"]


def test_render_stage_formats_are_never_dispatched(tmp_path: Path):
    """demo/gif belong to the render stage: produce() must not re-produce them.

    Re-running them here would rewrite demo.mp4 — a protected artifact — from
    outside the stage that the verified verdict is attached to.
    """
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)
    results = produce(m._run_dir, m, cfg_with_formats("demo", "gif"))
    assert results == {}
    assert Manifest.load(m._run_dir).formats == {}


# -- the verified gate ---------------------------------------------------------


def test_unverified_run_skips_every_extra_format_with_a_recorded_reason(
    tmp_path: Path, monkeypatch
):
    """Regression (#230): formats are gated on manifest.verified, like render.

    An unverified run gets no promo cut — and, exactly as _stage_render records
    "replay unverified — no video", the refusal is recorded with its reason
    rather than being a silent no-op.
    """
    calls: list[Path] = []

    def builder(run_dir, manifest, cfg):
        calls.append(run_dir)

    m = make_manifest(tmp_path, verified=False)
    seed_protected(m._run_dir)
    # setitem, not register_builder + pop: "promo" now has a real registered
    # builder (#170), and popping it would leave the registry damaged for every
    # test that runs after this one.
    monkeypatch.setitem(produce_mod._BUILDERS, "promo", builder)
    results = produce(m._run_dir, m, cfg_with_formats("demo", "gif", "promo"))

    assert results == {"promo": "skipped: replay unverified — no extra formats"}
    assert calls == [], "no builder may run on an unverified run"
    assert Manifest.load(m._run_dir).formats == results


# -- builder lookup ------------------------------------------------------------


def test_format_without_a_builder_is_skipped_not_failed(tmp_path: Path):
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)
    results = produce(m._run_dir, m, cfg_with_formats("podcast"))
    assert results == {"podcast": "skipped: no builder registered for 'podcast'"}


#: A module path this repo will never ship, so the "not landed yet" premise
#: below cannot go stale the way it did when ``readme2demo.promo`` landed.
_UNLANDED_MODULE = "readme2demo._no_such_format_builder"


def test_optional_builder_whose_module_has_not_landed_is_a_skip(tmp_path: Path, monkeypatch):
    """Regression (#230/#170): a declared-but-absent builder module never crashes.

    The property: an optional row may name a module that does NOT exist — that
    is what makes it safe to declare a format before its PR lands — and the
    format degrades to a recorded skip instead of an ImportError that would
    take the run down with it.

    It used to be pinned with ``readme2demo.promo``, which was genuinely absent
    when this test was written and is now the #170 compositor: the premise
    quietly inverted and the test failed on the integration branch. It is
    therefore pinned against a module this repo will never ship, and the
    premise is asserted (``find_spec`` is None) rather than assumed, so a
    future landing cannot invert it silently again.
    """
    import importlib.util

    assert importlib.util.find_spec(_UNLANDED_MODULE) is None, (
        f"{_UNLANDED_MODULE} exists — this test needs a module that does not"
    )
    monkeypatch.setitem(
        produce_mod._OPTIONAL_BUILDERS, "podcast", (_UNLANDED_MODULE, "build_podcast")
    )
    assert builder_for("podcast") is None
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)
    results = produce(m._run_dir, m, cfg_with_formats("podcast"))
    assert results["podcast"].startswith("skipped: no builder registered")


def test_optional_builder_whose_attribute_has_not_landed_is_a_skip(tmp_path: Path, monkeypatch):
    """Regression (#230/#170): the other half — module present, entry point absent.

    The successor state of the test above now that ``readme2demo.promo`` is a
    real module: a row may point into a module that exists but does not (yet)
    expose the named callable, and that is still a skip, not an AttributeError.
    """
    monkeypatch.setitem(
        produce_mod._OPTIONAL_BUILDERS, "podcast", ("readme2demo.promo", "build_podcast")
    )
    assert builder_for("podcast") is None
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)
    results = produce(m._run_dir, m, cfg_with_formats("podcast"))
    assert results["podcast"].startswith("skipped: no builder registered")


def test_optional_builder_is_resolved_lazily_once_its_module_exists(
    tmp_path: Path, monkeypatch
):
    """The lookup imports on demand, so a later PR's module wires itself in."""
    import sys
    import types

    module = types.ModuleType("fake_format_builders")
    seen: list[Path] = []
    module.build = lambda run_dir, manifest, cfg: seen.append(run_dir)  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "fake_format_builders", module)
    monkeypatch.setitem(
        produce_mod._OPTIONAL_BUILDERS, "podcast", ("fake_format_builders", "build")
    )

    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)
    assert produce(m._run_dir, m, cfg_with_formats("podcast")) == {"podcast": PRODUCED}
    assert seen == [m._run_dir]


def test_non_callable_attribute_resolves_to_no_builder(monkeypatch):
    import sys
    import types

    module = types.ModuleType("fake_format_builders")
    module.build = "not callable"  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "fake_format_builders", module)
    monkeypatch.setitem(
        produce_mod._OPTIONAL_BUILDERS, "podcast", ("fake_format_builders", "build")
    )
    assert builder_for("podcast") is None


def test_explicit_registration_wins_over_an_optional_row(monkeypatch):
    """Registered builders are checked first — the promo's row is never consulted.

    The two tests above used to be written against "promo"; they now use a
    format with no built-in builder, and this pins the reason why.
    """
    monkeypatch.setitem(
        produce_mod._OPTIONAL_BUILDERS, "promo", (_UNLANDED_MODULE, "render_promo")
    )
    assert builder_for("promo") is produce_mod.build_promo


# -- best-effort execution -----------------------------------------------------


def test_registered_builder_runs_and_is_recorded_produced(tmp_path: Path, monkeypatch):
    def builder(run_dir, manifest, cfg):
        (run_dir / "promo.mp4").write_bytes(b"promo")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", builder)
    m = make_manifest(tmp_path)
    before = seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("demo", "gif", "promo"))

    assert results == {"promo": PRODUCED}
    assert (m._run_dir / "promo.mp4").read_bytes() == b"promo"
    assert Manifest.load(m._run_dir).formats == {"promo": PRODUCED}
    for name, data in before.items():
        assert (m._run_dir / name).read_bytes() == data


def test_regression_raising_builder_is_recorded_and_never_propagates(
    tmp_path: Path, monkeypatch
):
    """Regression (#230): a builder exception is data, not a run failure.

    Generalizes render._generate_gif_preview's contract — "failure here never
    fails the stage" — to every optional output.
    """
    def builder(run_dir, manifest, cfg):
        raise RuntimeError("compositor died mid-frame")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", builder)
    m = make_manifest(tmp_path)
    before = seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert results["promo"] == (
        "skipped: builder failed — RuntimeError: compositor died mid-frame"
    )
    assert Manifest.load(m._run_dir).formats == results
    for name, data in before.items():
        assert (m._run_dir / name).read_bytes() == data


def test_one_bad_builder_does_not_stop_the_next_format(tmp_path: Path, monkeypatch):
    def boom(run_dir, manifest, cfg):
        raise ValueError("nope")

    def ok(run_dir, manifest, cfg):
        (run_dir / "social.mp4").write_bytes(b"social")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", boom)
    monkeypatch.setitem(produce_mod._BUILDERS, "social", ok)
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("promo", "social"))

    assert results["promo"].startswith("skipped: builder failed — ValueError")
    assert results["social"] == PRODUCED


# -- the protected-artifact guard ----------------------------------------------


def test_regression_builder_mutating_a_protected_artifact_is_recorded_untrusted(
    tmp_path: Path, monkeypatch
):
    """Regression (#230): an optional output may not reach the grounding path.

    demo.tape / step_by_step.md / commands.sh / demo.mp4 are the artifacts a
    fresh container validated. A builder that writes one has left the
    presentation layer, so its output is marked untrusted in the manifest
    instead of shipping as a success.
    """
    def vandal(run_dir, manifest, cfg):
        (run_dir / "demo.tape").write_text("Type 'rm -rf /'\n")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", vandal)
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert results["promo"].startswith("skipped: builder mutated protected artifact(s)")
    assert "demo.tape" in results["promo"]
    assert Manifest.load(m._run_dir).formats == results


def test_builder_creating_an_absent_protected_artifact_is_caught(
    tmp_path: Path, monkeypatch
):
    """The absent-file sentinel: creating demo.mp4 counts as mutating it."""
    def creator(run_dir, manifest, cfg):
        (run_dir / "demo.mp4").write_bytes(b"a video nobody verified")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", creator)
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir, skip=("demo.mp4",))

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert "demo.mp4" in results["promo"]
    assert results["promo"].startswith("skipped: builder mutated")


def test_mutation_by_one_builder_is_not_blamed_on_the_next(tmp_path: Path, monkeypatch):
    def vandal(run_dir, manifest, cfg):
        (run_dir / "commands.sh").write_text("# rewritten\n")

    def innocent(run_dir, manifest, cfg):
        (run_dir / "social.mp4").write_bytes(b"social")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", vandal)
    monkeypatch.setitem(produce_mod._BUILDERS, "social", innocent)
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("promo", "social"))

    assert results["promo"].startswith("skipped: builder mutated")
    assert results["social"] == PRODUCED


def test_raising_builder_that_also_damaged_an_artifact_reports_the_mutation(
    tmp_path: Path, monkeypatch
):
    """A builder that dies halfway is the one most likely to leave damage."""
    def half_written(run_dir, manifest, cfg):
        (run_dir / "step_by_step.md").write_text("truncated")
        raise OSError("disk full")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", half_written)
    m = make_manifest(tmp_path)
    seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert results["promo"].startswith("skipped: builder mutated")
    assert "step_by_step.md" in results["promo"]


# -- manifest field ------------------------------------------------------------


def test_record_formats_merges_and_persists(tmp_path: Path):
    m = make_manifest(tmp_path)
    m.record_formats({"promo": PRODUCED})
    m.record_formats({"social": "skipped: no builder registered for 'social'"})
    loaded = Manifest.load(m._run_dir)
    assert loaded.formats == {
        "promo": PRODUCED,
        "social": "skipped: no builder registered for 'social'",
    }


def test_manifests_written_before_the_formats_field_still_load(tmp_path: Path):
    """Regression (#230): the new field is additive — old runs keep resuming."""
    m = Manifest.create(tmp_path / "old", _URL, "claude-code", "img")
    raw = m.model_dump()
    raw.pop("formats")
    assert Manifest.model_validate(raw).formats == {}


def test_formats_are_not_stages(tmp_path: Path):
    """STAGES is untouched: a format never gates or resumes the pipeline."""
    from readme2demo.manifest import STAGES

    assert STAGES == [
        "ingest", "agent", "normalize", "distill", "verify", "tutorial", "render",
    ]
    m = make_manifest(tmp_path)
    m.record_formats({"promo": "skipped: builder failed — RuntimeError: boom"})
    assert set(m.stages) == set(STAGES)
    assert "promo" not in m.stages


# -- orchestrator wiring -------------------------------------------------------

# Full-pipeline fakes: deterministic bytes, no timestamps or paths in any
# artifact, so two runs of the same pipeline are byte-identical by construction
# and the only variable under test is the extra format.

_COMMANDS_SH = "#!/usr/bin/env bash\nset -e\npython hello.py\n"
_GUIDE_DRAFT = "# Guide (draft)\n\n```bash\npython hello.py\n```\n"
_GUIDE_FINAL = "# Guide\n\n```bash\npython hello.py\n```\n\nHello, world!\n"
_TAPE = 'Set TypingSpeed 50ms\nType "python hello.py"\nEnter\n'
_MP4 = b"\x00\x00\x00\x18ftypmp42" + b"deterministic frames" * 8


def install_fake_stages(monkeypatch, *, verified: bool = True) -> None:
    """Monkeypatch every stage so the pipeline runs offline and deterministically."""
    from readme2demo import distill as distill_mod
    from readme2demo import ingest as ingest_mod
    from readme2demo import normalize as normalize_mod
    from readme2demo import render as render_mod
    from readme2demo import tutorial as tutorial_mod
    from readme2demo import verify as verify_mod
    from readme2demo.types import (
        AgentResult,
        CommandLog,
        DistillOutput,
        Plan,
        SuccessCriteria,
        TutorialOutline,
        TutorialStep,
        VerifyReport,
    )

    plan = Plan(
        quickstart_summary="run the hello example",
        success_criteria=SuccessCriteria(command="python hello.py"),
    )
    outline = TutorialOutline(
        title="T", intro="i",
        steps=[TutorialStep(title="s", command="python hello.py", explanation="e")],
    )

    def fake_ingest(repo_url, run_dir, model, **kwargs):
        (run_dir / "plan.json").write_text(plan.model_dump_json())
        return plan, "abc1234", 0.0

    def fake_run_agent(run_dir, p, engine, c):
        (run_dir / "transcript.ndjson").write_text("")
        return run_dir / "transcript.ndjson"

    def fake_normalize(path, engine, run_dir):
        log = CommandLog(engine="claude-code", result=AgentResult(outcome="success"))
        (run_dir / "command_log.json").write_text(log.model_dump_json())
        return log

    def fake_distill(p, log, readme, run_dir, model, repo_url, feedback=""):
        (run_dir / "commands.sh").write_text(_COMMANDS_SH)
        (run_dir / "step_by_step.md").write_text(_GUIDE_DRAFT)
        (run_dir / "tutorial_outline.json").write_text(outline.model_dump_json())
        return DistillOutput(commands=["python hello.py"], tape=[], outline=outline), 0.0

    def fake_verify(run_dir, p, c):
        return VerifyReport(passed=verified, attempts=1, exit_code=0 if verified else 1)

    def fake_run_tutorial(run_dir, *args, **kwargs):
        (run_dir / "step_by_step.md").write_text(_GUIDE_FINAL)
        (run_dir / "tutorial.md").write_text("# tutorial\n")
        return 0.0

    def fake_build_tape(run_dir, log, repo_url, fallback):
        (run_dir / "demo.tape").write_text(_TAPE)
        return {"guide_steps": 1, "tape_steps": 1}

    def fake_render(run_dir, c, image=None):
        (run_dir / "demo.mp4").write_bytes(_MP4)
        return [run_dir / "demo.mp4"]

    monkeypatch.setattr(ingest_mod, "ingest", fake_ingest)
    monkeypatch.setattr("readme2demo.orchestrator.run_agent", fake_run_agent)
    monkeypatch.setattr(normalize_mod, "normalize", fake_normalize)
    monkeypatch.setattr(distill_mod, "distill", fake_distill)
    monkeypatch.setattr(verify_mod, "run_verify", fake_verify)
    monkeypatch.setattr(tutorial_mod, "run_tutorial", fake_run_tutorial)
    monkeypatch.setattr(distill_mod, "build_tape_from_step_by_step", fake_build_tape)
    monkeypatch.setattr(render_mod, "run_render", fake_render)
    monkeypatch.setattr(
        render_mod, "validate_outputs", lambda run_dir, **kw: [run_dir / "demo.mp4"]
    )


def test_regression_failing_format_leaves_the_run_byte_identical(
    tmp_path: Path, monkeypatch
):
    """Regression (#230): the acceptance criterion of the issue.

    Run the pipeline twice — once plain, once with an extra format whose builder
    raises — and demand that demo.mp4, step_by_step.md, commands.sh and
    demo.tape come out byte-identical, and that the run with the failing format
    still succeeds (every stage completed, verified verdict intact).
    """
    install_fake_stages(monkeypatch)

    baseline = Orchestrator.new_run(_URL, Config(runs_dir=tmp_path))
    baseline_manifest = baseline.run()

    dispatched: list[Path] = []

    def exploding_builder(run_dir, manifest, cfg):
        dispatched.append(run_dir)
        raise RuntimeError("compositor died mid-frame")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", exploding_builder)
    with_format = Orchestrator.new_run(
        _URL, cfg_with_formats("demo", "gif", "promo", runs_dir=tmp_path)
    )
    format_manifest = with_format.run()

    assert dispatched == [with_format.run_dir], "the builder must really have run"
    for name in PROTECTED_ARTIFACTS:
        assert (baseline.run_dir / name).read_bytes() == (
            with_format.run_dir / name
        ).read_bytes(), f"{name} differs when an extra format fails"

    # ... and the run itself is unaffected: nothing left to do, nothing failed.
    assert format_manifest.next_stage() is None
    assert format_manifest.verified is True
    assert all(
        rec.status == "completed" for rec in format_manifest.stages.values()
    )
    assert format_manifest.stages["render"].error is None
    # The failure is recorded as data, and only on the run that asked for it.
    assert format_manifest.formats["promo"].startswith(
        "skipped: builder failed — RuntimeError"
    )
    assert baseline_manifest.formats == {}


def test_produce_runs_after_render_on_the_unverified_path(tmp_path: Path, monkeypatch):
    """Regression (#230): the gate is reachable — render skips, produce records.

    _stage_render returns early on an unverified run, so the dispatch hook has
    to hang off the stage in run(), not off the render work itself; otherwise an
    unverified run would silently record nothing about its extra formats.
    """
    install_fake_stages(monkeypatch, verified=False)

    def builder(run_dir, manifest, cfg):
        raise AssertionError("must not be dispatched on an unverified run")

    monkeypatch.setitem(produce_mod._BUILDERS, "promo", builder)
    cfg = cfg_with_formats("demo", "gif", "promo", runs_dir=tmp_path, distill_retries=0)
    orch = Orchestrator.new_run(_URL, cfg)
    manifest = orch.run()

    assert manifest.verified is False
    assert manifest.stages["render"].status == "skipped"
    assert manifest.formats == {"promo": "skipped: replay unverified — no extra formats"}
    assert Manifest.load(orch.run_dir).formats == manifest.formats


def test_produce_failure_outside_a_builder_still_cannot_fail_the_run(
    tmp_path: Path, monkeypatch
):
    """Belt and braces: even a broken produce() only costs a warning line."""
    install_fake_stages(monkeypatch)

    def broken_produce(run_dir, manifest, cfg):
        raise RuntimeError("registry exploded")

    monkeypatch.setattr(produce_mod, "produce", broken_produce)
    orch = Orchestrator.new_run(_URL, Config(runs_dir=tmp_path))
    manifest = orch.run()

    assert manifest.next_stage() is None
    assert manifest.stages["render"].status == "completed"
    assert (orch.run_dir / "demo.mp4").read_bytes() == _MP4


def test_default_run_dispatches_and_records_nothing(tmp_path: Path, monkeypatch):
    """No --formats: produce() is inert, so today's runs are unchanged."""
    install_fake_stages(monkeypatch)
    orch = Orchestrator.new_run(_URL, Config(runs_dir=tmp_path))
    manifest = orch.run()
    assert manifest.formats == {}
    assert Manifest.load(orch.run_dir).formats == {}


def test_protected_artifact_list_is_the_grounding_set():
    """The four artifacts CLAUDE.md names as the grounding path, pinned.

    Widening this set is fine; silently narrowing it would quietly un-guard a
    published artifact, so the list is asserted exactly.
    """
    assert PROTECTED_ARTIFACTS == (
        "demo.mp4", "step_by_step.md", "commands.sh", "demo.tape",
    )


# -- the promo builder (#170) --------------------------------------------------

# Both halves of the promo are replaced: run_promo_script (the paid LLM pass)
# and render_promo (docker + ffmpeg). What is under test is the adapter between
# them — what it loads, what it publishes, and where the money is recorded.

_TIMESTAMPS = {
    "total_min_s": 12.0,
    "steps": [
        {
            "index": 0,
            "cmd": "python hello.py",
            "title": "Run the example",
            "start_min_s": 1.0,
            "end_min_s": 5.0,
        }
    ],
}


def seed_promo_inputs(run_dir: Path) -> None:
    """Write the run artifacts build_promo reads, minus the guide.

    ``step_by_step.md`` is one of the four PROTECTED_ARTIFACTS, so it comes
    from :func:`seed_protected` — the promo's guide input IS the published
    guide, which is the point of reading it rather than the distiller's draft.
    """
    plan = Plan(
        quickstart_summary="run the hello example",
        success_criteria=SuccessCriteria(command="python hello.py"),
    )
    log = CommandLog(
        engine="claude-code",
        entries=[CommandEntry(cmd="python hello.py", exit_code=0)],
        result=AgentResult(outcome="success"),
    )
    (run_dir / "plan.json").write_text(plan.model_dump_json())
    (run_dir / "command_log.json").write_text(log.model_dump_json())
    (run_dir / "step_timestamps.json").write_text(json.dumps(_TIMESTAMPS))


def promo_script_fixture() -> PromoScript:
    """A scene list of the shape run_promo_script returns once validated."""
    return PromoScript(
        total_duration_s=8.0,
        scenes=[
            PromoScene(kind="title_card", text="x/y — verified", duration_s=2.0),
            PromoScene(
                kind="demo_segment", step_index=0, start_s=1.0, end_s=5.0, duration_s=4.0
            ),
            PromoScene(kind="end_card", text="python hello.py", duration_s=2.0),
        ],
    )


def promo_run(tmp_path: Path, *, name: str = "run") -> Manifest:
    """A verified run dir with every artifact the promo builder needs."""
    m = make_manifest(tmp_path, name=name)
    seed_protected(m._run_dir)
    seed_promo_inputs(m._run_dir)
    return m


def install_promo_fakes(
    monkeypatch,
    *,
    cost: float = 0.0,
    script: PromoScript | None = None,
    rendered: str | None = "promo.mp4",
    raises: BaseException | None = None,
) -> dict:
    """Replace the LLM pass and the compositor; return a call recorder.

    ``rendered=None`` models render_promo's refusal contract: ``None`` back,
    while whatever it wrote stays on disk.
    """
    seen: dict = {"script_calls": [], "render_calls": []}
    plan_script = script or promo_script_fixture()

    def fake_run_promo_script(plan, log, guide_text, timestamps, model, **kwargs):
        seen["script_calls"].append(
            {
                "plan": plan,
                "log": log,
                "guide_text": guide_text,
                "timestamps": timestamps,
                "model": model,
                **kwargs,
            }
        )
        if raises is not None:
            raise raises
        return plan_script, cost

    def fake_render_promo(run_dir, script, cfg, **kwargs):
        seen["render_calls"].append({"run_dir": run_dir, "script": script, **kwargs})
        # A real render writes the file even on the path where it then refuses
        # to return it — that stale artifact is the evidence promo.log names.
        (run_dir / "promo.mp4").write_bytes(b"promo frames")
        return None if rendered is None else run_dir / rendered

    monkeypatch.setattr(promo_script_mod, "run_promo_script", fake_run_promo_script)
    monkeypatch.setattr(promo_mod, "render_promo", fake_render_promo)
    return seen


def test_promo_is_registered_by_default():
    """The last mile: --formats promo resolves to a builder without any wiring."""
    assert builder_for(PROMO_FORMAT) is build_promo


def test_regression_promo_builder_produces_promo_mp4_and_records_produced(
    tmp_path: Path, monkeypatch
):
    """Regression (#230/#170): the happy path of the wired promo format.

    Three modules that shipped in separate PRs (#255 the scene planner, #254
    the compositor, #253 the dispatch) produce one artifact: promo.mp4, plus
    promo_script.json, recorded as "produced" in manifest.formats — and none of
    the four protected artifacts moves a byte.
    """
    seen = install_promo_fakes(monkeypatch, cost=0.0123)
    m = promo_run(tmp_path)
    before = seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("demo", "gif", "promo"))

    assert results == {"promo": PRODUCED}
    assert (m._run_dir / "promo.mp4").read_bytes() == b"promo frames"
    assert Manifest.load(m._run_dir).formats == {"promo": PRODUCED}
    for name, data in before.items():
        assert (m._run_dir / name).read_bytes() == data

    # promo_script.json is written through promo_script's own writer, from the
    # SAME object handed to the compositor — one scene list, one artifact.
    written = promo_script_mod.load_promo_script(m._run_dir)
    assert written is not None
    assert written.model_dump() == seen["render_calls"][0]["script"].model_dump()

    # The planner is fed the run's own artifacts, not re-derived ones.
    call = seen["script_calls"][0]
    assert call["plan"].success_criteria.command == "python hello.py"
    assert call["log"].entries[0].cmd == "python hello.py"
    assert call["guide_text"] == "step_by_step.md contents\n"
    assert call["timestamps"] == _TIMESTAMPS
    assert call["repo_url"] == _URL


def test_regression_promo_llm_cost_reaches_the_manifest(tmp_path: Path, monkeypatch):
    """Regression (#230/#170): a paid format's spend is accounted (#103/#209).

    The promo is the first output format that costs money. If the cost stopped
    at the builder, a run would report a total that is missing every dollar it
    spent on the cut — the same bug stage_fail(cost_usd=...) was added to fix.
    """
    install_promo_fakes(monkeypatch, cost=0.0725)
    m = promo_run(tmp_path)

    produce(m._run_dir, m, cfg_with_formats("promo"))

    loaded = Manifest.load(m._run_dir)
    assert loaded.format_costs == {"promo": 0.0725}
    assert loaded.total_cost_usd == 0.0725
    # ... and it survives the next stage transition, because the total is
    # recomputed from every source of spend, not just the stage records.
    m.stage_complete("render", cost_usd=0.25)
    assert Manifest.load(m._run_dir).total_cost_usd == 0.3225


def test_regression_failing_promo_script_is_a_skip_that_still_records_its_cost(
    tmp_path: Path, monkeypatch
):
    """Regression (#230/#170): a PAID failure records the money AND skips.

    PromoScriptError arrives after up to two LLM calls (generate + grounding
    retry) and carries cost_usd for exactly this reason. The run must come out
    byte-identical, the format recorded as skipped, and the spend still on the
    books — a failure that reports $0.00 is the bug, not the failure.
    """
    install_promo_fakes(
        monkeypatch,
        raises=PromoScriptError("still ungrounded after retry", cost_usd=0.019),
    )
    m = promo_run(tmp_path)
    before = seed_protected(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert results["promo"].startswith("skipped: builder failed — PromoScriptError")
    assert "still ungrounded after retry" in results["promo"]
    loaded = Manifest.load(m._run_dir)
    assert loaded.formats == results
    assert loaded.format_costs == {"promo": 0.019}
    assert loaded.total_cost_usd == 0.019
    # Byte-identical: an optional output may not touch the grounding path.
    for name, data in before.items():
        assert (m._run_dir / name).read_bytes() == data
    assert not (m._run_dir / "promo.mp4").exists()
    assert not (m._run_dir / "promo_script.json").exists()


def test_regression_a_broken_cost_on_the_error_never_masks_the_error(
    tmp_path: Path, monkeypatch
):
    """Regression (#230/#170): rescuing the spend must not replace the failure.

    The cost is read off a live exception while it propagates. A ``cost_usd``
    that is not a number would make ``float()`` raise there and the run would
    be told the promo died of a TypeError — hiding the reason it actually died.
    """
    class WeirdError(RuntimeError):
        cost_usd = "not a number"

    install_promo_fakes(monkeypatch, raises=WeirdError("planner exploded"))
    m = promo_run(tmp_path)

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert results["promo"].startswith("skipped: builder failed — WeirdError")
    assert "planner exploded" in results["promo"]
    assert Manifest.load(m._run_dir).format_costs == {"promo": 0.0}


def test_regression_none_from_render_promo_is_a_skip_even_with_a_file_on_disk(
    tmp_path: Path, monkeypatch
):
    """Regression (#230/#170): publish from the return value, never by globbing.

    render_promo leaves the un-validated cut in the run dir on purpose when its
    size/duration gate refuses it (test_failed_gate_returns_none_but_leaves_the
    _evidence pins that half). An adapter that treated "promo.mp4 exists" as
    success would publish exactly the truncated video the compositor refused.
    """
    install_promo_fakes(monkeypatch, cost=0.004, rendered=None)
    m = promo_run(tmp_path)

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert (m._run_dir / "promo.mp4").exists(), "the evidence file is left alone"
    assert results["promo"].startswith("skipped: builder failed — PromoError")
    assert "promo.log" in results["promo"]
    loaded = Manifest.load(m._run_dir)
    assert loaded.formats == results
    assert loaded.format_costs == {"promo": 0.004}  # the plan was still paid for


@pytest.mark.parametrize("missing", PROMO_INPUTS)
def test_regression_missing_run_artifact_is_a_skip_not_a_crash(
    tmp_path: Path, monkeypatch, missing: str
):
    """Regression (#230/#170): an incomplete run dir degrades, it does not raise.

    A run rendered with --skip-video, or one predating step_timestamps.json,
    has no footage table to cut against. That is a recorded skip naming the
    file — and it must cost nothing, because the LLM is never reached.

    Parametrized over PROMO_INPUTS so the documented input set is the one the
    builder really requires: an input added to that tuple is checked here, and
    one the builder stops needing has to leave the tuple.
    """
    seen = install_promo_fakes(monkeypatch, cost=1.0)
    m = promo_run(tmp_path, name=f"run-{missing}")
    (m._run_dir / missing).unlink()

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert results["promo"].startswith("skipped: builder failed — FileNotFoundError")
    assert missing in results["promo"]
    assert seen["script_calls"] == [], "no paid call on an unusable run dir"
    assert Manifest.load(m._run_dir).format_costs == {}


def test_regression_unknown_promo_style_fails_before_the_paid_call(
    tmp_path: Path, monkeypatch
):
    """Regression (#230/#170): a config typo must not cost an LLM call.

    Same rule as the ingest infeasibility gate — fail for pennies, before the
    expensive part. The style/duration presets are validated up front, so a
    misspelt --promo-style is a skip with a spend of zero.
    """
    seen = install_promo_fakes(monkeypatch, cost=1.0)
    m = promo_run(tmp_path)
    cfg = cfg_with_formats("promo").model_copy(update={"promo_style": "neon"})

    results = produce(m._run_dir, m, cfg)

    assert results["promo"].startswith("skipped: builder failed — PromoError")
    assert "unknown promo style" in results["promo"]
    assert seen["script_calls"] == []
    assert Manifest.load(m._run_dir).format_costs == {}


def test_promo_style_and_duration_are_read_defensively_from_config(
    tmp_path: Path, monkeypatch
):
    """Defaults today, config values once the flags land — like requested_formats.

    Config has no promo_style/promo_duration field yet (it arrives with the
    --formats registry PR), so the builder reads both through getattr and this
    wiring does not depend on that PR landing first.
    """
    seen = install_promo_fakes(monkeypatch)
    m = promo_run(tmp_path)
    assert getattr(Config(), "promo_style", None) is None

    produce(m._run_dir, m, cfg_with_formats("promo"))
    assert seen["render_calls"][0]["style"] == promo_mod.DEFAULT_STYLE
    assert seen["render_calls"][0]["preset"] == promo_mod.DEFAULT_DURATION
    # The cut is PLANNED for the same budget the compositor then enforces —
    # the IDENTICAL (style, preset) pair, not a number derived from it. The
    # planner's budget violation is that same duration gate applied early, so
    # any drift between the two makes it police a cut nobody will render.
    assert seen["script_calls"][0]["style"] == seen["render_calls"][0]["style"]
    assert seen["script_calls"][0]["preset"] == seen["render_calls"][0]["preset"]
    assert seen["script_calls"][0]["preset"] == promo_mod.DEFAULT_DURATION

    seen2 = install_promo_fakes(monkeypatch)
    m2 = promo_run(tmp_path, name="run2")
    cfg = cfg_with_formats("promo").model_copy(
        update={"promo_style": "energetic", "promo_duration": 15}
    )
    assert produce(m2._run_dir, m2, cfg) == {"promo": PRODUCED}
    assert seen2["render_calls"][0]["style"] == "energetic"
    assert seen2["render_calls"][0]["preset"] == 15
    assert seen2["script_calls"][0]["style"] == "energetic"
    assert seen2["script_calls"][0]["preset"] == 15


def test_regression_promo_never_runs_on_an_unverified_run(tmp_path: Path, monkeypatch):
    """Regression (#230/#170): the verified gate covers the real builder too.

    Not a re-test of the gate: a promo of an unverified run would be a shareable
    video of commands no fresh container ever executed, so the wired-in builder
    (not just a test double) must be unreachable on that path — and cost zero.
    """
    seen = install_promo_fakes(monkeypatch, cost=2.0)
    m = make_manifest(tmp_path, verified=False)
    seed_protected(m._run_dir)
    seed_promo_inputs(m._run_dir)

    results = produce(m._run_dir, m, cfg_with_formats("promo"))

    assert results == {"promo": "skipped: replay unverified — no extra formats"}
    assert seen["script_calls"] == [] and seen["render_calls"] == []
    assert Manifest.load(m._run_dir).format_costs == {}
    assert not (m._run_dir / "promo.mp4").exists()


def test_manifests_written_before_the_format_costs_field_still_load(tmp_path: Path):
    """Regression (#170): the cost map is additive — old runs keep resuming."""
    m = Manifest.create(tmp_path / "old-costs", _URL, "claude-code", "img")
    raw = m.model_dump()
    raw.pop("format_costs")
    assert Manifest.model_validate(raw).format_costs == {}
