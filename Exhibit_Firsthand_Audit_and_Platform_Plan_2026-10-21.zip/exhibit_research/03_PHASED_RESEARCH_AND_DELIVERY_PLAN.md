# Phased plan: evidence gates first, engineering depth where earned

## Goal

Achieve an impressive working Exhibit kernel during the Meta hackathon, while establishing modular boundaries for a future one-stop software behavior evidence platform. Scope is capability-driven, not page-count-driven. Winning cannot be guaranteed.

**Compliance gate:** The official rules have not yet been accepted/published in this conversation. Research artifacts are kept separately. Do not assume any pre-kickoff product code is competition-eligible, and do not misrepresent its creation date.

## Phase R0: adversarial upstream audit (pre-event)

**Delivered in this tranche:** source snapshots hashed, selective unit checks executed, first direct-function probes captured. **Still open:** OSS-Fuzz-Gen dependency resolution and full pipeline, Rust backcheck execution, actual model runs and Docker clean-room tests.

- Complete dependency graph, entry-point calls and attack surface matrix for each competitor.
- Run all reachable code under disposable resources, not host unrestricted shell.
- Verify command equivalence assumptions and replay semantics by differential probes.
- Preserve one-page finding per issue: exact version, code location, reproduction, observed versus expected, full-pipeline limitations, possible mitigation and relevance to Exhibit.
- Gate: at least one execution-derived fact per competitor, or an explicit `BLOCKED` with missing requirements and next feasible reproduction path.

## Phase R1: ground-truth benchmark design (pre-event research)

- Define preregistered fixture manifest with paired correct/incorrect implementations and **blinded** labels held separately from planners.
- Claim families: caching, idempotency, durability/recovery and isolation/authorization; choose final families by setup feasibility and discriminating power, not assumptions.
- Negatives: requests never reaching target, non-landed faults, logs from wrong instance, stale cached telemetry, an oracle that asserts on a mocked path, unexpected cache TTL, legitimate nondeterminism, asynchronous convergence, partial observability.
- Controls: empty/test-free project, misleading README, modified setup instructions, poisoned docs/AGENTS.md, incorrect resource constraints, environment mismatch and hidden backend dependency.
- Build checker-coverage tests and oracle mutation/negative controls before giving an LLM any access to the fixtures.
- Gate: a human reviewer can classify each synthetic fixture based on external ground truth; a weak oracle is caught by deliberate mutation; no known label leaks into model input.

## Phase R2: architecture tournament (begin with throwaway research where allowed)

Test A free-form agent, B typed adapter compiler, C adaptive causal planner. Same model, same blind claim, same tool access, same time/tokens and independently pinned executor. Randomized order and frozen model parameters/seeds where supported.

- Count completed plans, valid observability, genuine contradictions, unsupported accusations, correct abstentions, replay successes, total calls, input/output/cache tokens, total priced tokens, actual provider bill, CPU/memory, p50/p95 wall time and retry rate.
- At least three runs/condition initially for debugging; expand before making comparative claims. Treat any small-sample percentages as descriptive only.
- Gate: choose architecture by false-accusation-adjusted discovery yield (valid contradictions per budget), with reproducibility and operational risks included. If no significant benefit, choose simplest observed route, not favorite design.

## Phase R3: platform contract freeze (before product implementation)

- Finalize canonical JSON schemas, explicit oracle semantics, valid preconditions, executor action DSL and adapter protocol.
- Freeze threat model: model may read untrusted source but never execute repo instructions as privileged commands; separate sandbox and host ledger; secret/egress policy.
- ADRs for structured event store, exact environment identity, replay identity, cost accounting and failure taxonomy.
- Full repo structure, CONTRIBUTING.md, `AGENTS.md`, CI matrix, lint/type/test policies, VERSIONING.md, BUILD.md, THREAT_MODEL.md, security disclosure and sample provenance records.
- Gate: spec approved; API/schema contract tests and threat scenarios reviewed before implementation.

## Phase B1: traceable vertical slice (competition eligible window)

- Create isolated repo/worktree only after rule clarification and design approval.
- TDD claim intake -> contract -> plan -> observer -> oracle -> report -> fresh replay.
- Implement one exceptionally strong experiment family and a complete counterexample, no mocked model output presented as a live success.
- Model adapter can be swapped without changing executor or oracle.
- Gate: reproducible failure and healthy paired negative control, environment and event receipts, independently audited finding.

## Phase B2: expand capability **through stable contracts**

- Add a second *meaningfully different* claim family (e.g., stateful retries after pure caching), not five shallow variants.
- Support causal interventions and model feedback only if it improves measured discovery yield.
- Add fixture mutation suite, degradation/abstention and fatal failure policy.
- Gate: new adapter tests pass, existing negative controls remain clean, false-positive and budget regressions audited.

## Phase B3: comparative evaluation and hardening

- Blind head-to-head with Muse, available state-of-art coding agent and property/fuzzing baseline under matched resource ceilings.
- Test prompt injections, poisoned documentation, unsafe package installation, restart/network outage, corrupted/reordered evidence, replay on fresh state, resource exhaustion, API rate-limit failure and lost checkpoint.
- Publish per-finding failure details rather than cherry-picked aggregate numbers.
- Gate: claim-level report reproduces without model involvement; documented limitations and correct abstentions; baseline gains if claimed.

## Phase B4: judge-facing proof

- 120-second narrative: claim -> experimental decision -> independent intervention -> observed contradiction or scoped pass -> fresh repro.
- Demonstration must use real data; allow inspection of raw artifacts, environment identity and objective oracle.
- Reproducible CLI/SDK and evidence explorer; UI is read-only projection, not source of truth.
- Build/demo and README must match exact supported behavior. Archive artifact manifest and ensure submission rules satisfied.
- Gate: independent person can run demonstration from documented steps within predictable time and no secret credentials. Measure first-time setup, not only warm-run speed.

## Longer-term ecosystem (NOT hackathon deliverables unless proven feasible)

Organization policy packs, GitHub action/CI integration, continuous claim-regression monitoring, signed attestations, team/tenant workflows, distributed audit storage, SDK marketplace for claim adapters, provenance search and benchmarking service. Their future compatibility is enabled by the core contracts; their implementation is not implied by drawing their boxes.

## Scope discipline

No global support claim. No silent assumption that claimed caching means all keys and TTLs. No one-shot agent verdict. No hidden fallback from restricted DSL to unrestricted shell. No manually edited ledgers. No use of historical run data as current evidence. No splitting into microservices before observed scaling necessity.

## Team handoff / model cross-review

Require independent Claude review of: one code trace, one counterexample, one rejected hypothesis, one security boundary, one cost accounting example, and one hostile negative control. Every review gets exact archive hashes, tested commands, inputs, outputs and a request to falsify conclusions. Disagreement is recorded, not concealed. No model-generated praise counts as evidence.
