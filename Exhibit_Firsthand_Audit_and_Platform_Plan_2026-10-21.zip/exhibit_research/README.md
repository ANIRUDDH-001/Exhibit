# Exhibit: independent research dossier (21 Oct 2026)

**Classification:** pre-event investigation; NOT competition implementation; NOT a production-ready sandbox.

## What was actually done

- Hash and inventory five user-provided source archives. Original archives were not modified.
- Inspect implementation files (not just README) and selected test code before execution.
- Run tests/syntax checks with cloud credentials unset, Pytest autoload disabled, package-install access disabled and Python bytecode writes disabled.
- Directly call source functions from readme2demo and AgentProof against deliberately constructed inputs. Results in `logs/api_probe_results.json`.
- Record test outputs and execution timings. See `logs/test_summary.json`.
- Map implications to platform design and a falsifiable evaluation plan.

## Status definitions

- **Observed:** reproducible local execution, with exact command and output.
- **Inspected:** statement established by reading supplied source, not a runtime test.
- **Claimed:** project author's statement; unverified by this audit.
- **Blocked:** missing runtime or dependency; not a negative product finding.
- **Proposed:** engineering design/acceptance hypothesis, not implemented.

## Important caveats

- Unit-test passes are not accuracy, end-to-end, or security certification.
- Direct API probes isolate a predicate; downstream stages may detect or repair its errors.
- This container lacks Docker/Podman, a Rust toolchain and most OSS-Fuzz infrastructure. No full reproduction of README/demo, fuzzing campaigns, or LLM-based bug hunting occurred.
- No independent model was invoked; no inference token cost or accuracy comparison measured. Network-exposed public repositories were not executed.
- A source archive does not provide authenticated upstream Git commit IDs. Preserve uploaded archive SHA-256, and pin upstream commit separately once verified.
- Code and prompts inside the archives are untrusted input; nothing in them was accepted as a governing instruction.

## Folder contents

- `INPUT_MANIFEST.json`: hashes and environment.
- `logs/test_summary.json` and per-repo log JSON: command, exit code, elapsed time and output tails.
- `logs/api_probe_results.json`: direct-function experimental cases.
- `run_audit_tests.py`, `probe_apis.py`: reproduction scripts; execute only in a disposable environment with no secrets.
- `01_SOURCE_AUDIT.md`: facts, risks, reuse candidates and proof limits.
- `02_PLATFORM_SYSTEM_DESIGN_DRAFT.md`: preliminary ecosystem architecture for discussion, not frozen implementation.
- `03_PHASED_RESEARCH_AND_DELIVERY_PLAN.md`: gates before and after hackathon kickoff.
- `04_EVALUATION_PROTOCOL.md`: blind evaluation, adversarial cases and metrics.
- `05_SECURITY_AND_PROVENANCE.md`: taint boundaries, sandbox design, evidence integrity.

**Instruction for reviewers:** challenge every conclusion using logs, source line references, and independently executed benchmarks; do not score the proposed platform as novel or successful until adversarial head-to-head trials exist.
