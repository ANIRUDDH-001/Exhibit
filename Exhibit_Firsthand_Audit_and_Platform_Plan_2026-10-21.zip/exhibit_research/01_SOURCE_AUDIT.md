# First-hand source audit

## Evidence hierarchy

1. Local direct-function execution (within limited environment)
2. Local selected test execution
3. Specific source inspection, with path and function
4. Author documentation (not counted as direct proof)

All references below are in the supplied ZIP snapshots. Commit IDs are not guaranteed by those ZIPs; archive hashes are in `INPUT_MANIFEST.json`.

| Repository | Locally executed | Inspected functional mechanism | What is NOT established |
| --- | --- | --- | --- |
| AgentProof | `pytest -q tests/unit tests/test_core.py`: 50 passed, pytest 18.90 s | `agentproof/proof/tests.py::classify`, `run_proof_tests`; `proof/claims.py::normalize_claim` | AI-discovery of untested behavioral guarantees; production reliability |
| readme2demo | `pytest -q tests`: 755 passed, 1 skipped, pytest 2.22 s | `src/readme2demo/orchestrator.py`; `distill.py::is_grounded`; `verify.py::run_verify` | Real Docker replay or real model-driven execution in this environment |
| oss-fuzz-gen | `pytest -q agent_tests`: test collection failed with `ImportError: cannot import name 'storage' from google.cloud` | `pipeline.py::Pipeline`, `stage/execution_stage.py::ExecutionStage` | No verdict on test correctness or fuzzing performance |
| agentic-pbt | `python -m py_compile run.py scoring.py`: exit 0 | `hypo.md` property-generation protocol; `run.py` Claude CLI call, logging | Any successful agent run, cost/token accuracy, reproducibility in target env |
| backcheck | Not run (`cargo` not installed) | `src/claims.rs`, `src/verify.rs`, `src/evidence.rs` | Rust binary behavior on real agent transcripts |

**Wall-time observations:** AgentProof process wall time 21.073 s; readme2demo process wall time 4.25 s; OSS-Fuzz-Gen collection process wall time 1.941 s; agentic PBT syntax command 1.288 s. These cannot be used to compare product speed; they are different tests, dependencies and execution paths.

## Direct readme2demo predicates: seven cases

Consult `logs/api_probe_results.json` for exact inputs/outputs.

- Exact `python service.py` command: accepted; appropriate.
- Previously unseen `python different.py`: rejected; appropriate.
- `CACHE_ENABLED=1` recorded vs `CACHE_ENABLED=0` proposed: **accepted**.
- `BACKEND_URL=http://a` recorded vs `http://b` proposed: **accepted**.
- Heredoc writing `cache=on` recorded vs `cache=off` proposed: **accepted**.
- Executable path `/trusted/bin/python` recorded vs `/untrusted/bin/python` proposed: **accepted**.
- New `cd /bad-dir` command: **accepted** without execution evidence.

Mechanism: `distill.py::normalize_cmd`, `_strip_env_prefix`, `heredoc_prefix`, and `is_grounded`. Normalization discards some environment prefixes, canonicalizes executables and accepts heredoc prefixes without verifying their body. Acceptance is intentional or documented in parts of the source; it is unsound as *behavioral equivalence*. **Do not call this a verified complete-product exploit:** the subsequent `verify.py::run_verify` stage performs a fresh run and may reject bad scripts if its success criteria detect the deviation.

## Direct AgentProof results

- BASE pass / HEAD fail → `REGRESSION`.
- BASE fail / HEAD fail → `NOT_FIXED`.
- BASE pass / HEAD pass → `INCONCLUSIVE`.
- BASE fail / HEAD pass → `PROVEN`.
- `proof/claims.py::normalize_claim` maps caching and idempotency claims to `custom_claim`; maps `all tests pass` to `tests_pass`.

**Interpretation:** Proof-result classification is sensible for BASE/HEAD supplied commands. The inspected normalizer does not compile arbitrary behavioral claims into executable oracles. Do not infer that no other extension path can handle such claims without a comprehensive audit.

## Implementation lessons: candidate reuse, never blind copying

- **OSS-Fuzz-Gen:** measurement-feedback generation loop; generated harness + independent execution + coverage/crash feedback. `pipeline.py` explicitly limits cycles; count/cost must be configurable and metered in Exhibit.
- **Agentic PBT:** source-grounded property search and structured failure triage. Useful baseline for property claims; incomplete solution to external system behaviors.
- **readme2demo:** resumable state transitions, stage artifacts and fresh-environment replay; its command-grounding equivalence must not be imported as a behavioral oracle.
- **AgentProof:** BASE/HEAD behavioral counterfactual and explicit status taxonomy; suitable option for mutation/calibration checks.
- **backcheck:** claims/evidence separation and temporal reasoning; cannot take the agent narrative as its own evidence.

## Engineering implications

1. Store *actual* runtime configuration, executable hashes and dependency resolution, not just normalized commands.
2. A successful replay demonstrates the script completed as defined. It does not automatically demonstrate the advertised behavioral guarantee.
3. An oracle must have independently validated observation coverage, fault landing, and domain preconditions.
4. Materially different inputs cannot be grouped by heuristic command normalization without an explicit, scoped equivalence policy.
5. Partial progress and abstention must be first-class, machine-distinguishable results.
6. Test strong available coding agents under equivalent budgets; no assumption of Exhibit superiority.

## Outstanding audits

- Full run of OSS-Fuzz-Gen and a real fuzz campaign in a sandboxed environment with pinned dependencies and OSS-Fuzz infrastructure.
- Compile and run backcheck with Rust 1.85+ in isolated workspace.
- Run agentic PBT with an authorized model account and real target in an instrumented sandbox; record exact tokens, calls and wall time.
- readme2demo full Docker replay under both correct and falsified success predicates.
- Independent benchmark of modern general-purpose agents against blind fixtures.
