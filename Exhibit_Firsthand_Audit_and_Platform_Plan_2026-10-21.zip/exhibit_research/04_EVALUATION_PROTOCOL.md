# Evaluation protocol: truthfulness, reliability and efficiency

## Unit of measurement

A `(repo_SHA, claim_ID, contract_version, action_plan_hash, oracle_version, sandbox_digest, seed)` run; one outcome per completed evaluation. Repeated attempts are linked, never deduplicated away to inflate success.

## Outcomes

- `CONTRADICTED_REPRODUCIBLE`: actual predicate violation, sufficient observations, fresh rerun.
- `CONTRADICTED_NONDETERMINISTIC`: genuine violation observed, clean rerun failed to reproduce; report separately.
- `HELD_UNDER_TESTED_CONDITIONS`: preconditions met, checker fired on complete observation range, no observed violation; never say 'universally verified'.
- `ABSTAIN_AMBIGUOUS_CLAIM` / `ABSTAIN_WEAK_ORACLE` / `ABSTAIN_MISSING_OBSERVER` / `ABSTAIN_FAULT_UNPROVEN` / `BLOCKED_ENV` / `BLOCKED_POLICY` / `BUDGET_EXHAUSTED` / `INTERNAL_ERROR`: tracked separately.

## Validity gates

1. **Claim validity:** exact cited claim exists and applicability/preconditions are recorded.
2. **Execution validity:** all actions executed as frozen, SUT target and commit pinned, no test-only patch altering SUT semantics.
3. **Observation validity:** independent observer, complete operation ID coverage, calibrated clock, fault landing proof if relevant.
4. **Oracle validity:** predeclared, tested on negative/positive controls, relevant checker ran on data it claims to check.
5. **Freshness validity:** replay checks fresh cloned executable/artifact identity; no stale passes.
6. **Interpretation validity:** verdict phrasing matches claim strength and observed scope.

## Scorecard

For each architecture/model, track `TP`, `FP`, `TN`, `FN`, inconclusives, invalid cases and coverage, with human-adjudicated ground truth where possible. Report precision=TP/(TP+FP) only when denominator nonzero, recall=TP/(TP+FN), false-positive rate=FP/(FP+TN), abstention rate, accuracy conditional on coverage and separately overall. Add uncertainty intervals when sample size permits; never claim zero underlying FP probability from zero observed FPs.

**Efficiency:** total input/output/cache tokens, model calls, retries, model cost from actual billed usage, unsuccessful request overhead, runtime CPU/RAM/disk, p50/p95 latency by stage, sandbox startup time, environment setup time, reproducer duration, cost per valid reported counterexample, valid counterexamples per 1M tokens and per compute-hour.

**Reliability:** observer data completeness, replay success/ambiguity, sequence/hash chain integrity, idempotent resume behavior, non-landed fault detection rate, unsupported-claim rejection, environment drift, false accusations after corrupted history.

**Comparative discipline:** same repository SHA and conditions, model held fixed for architecture comparison, architecture fixed for model comparison, comparable total opportunity/budgets; preregister endpoints and stopping rules. Blind variants and avoid model seeing expected labels through path names. Record every failure and retry.

## Counterexample families (illustrative, not declared supported)

- Cache: repeated HTTP response but no backend cache interaction; accidental backend read after TTL; valid revalidation; intermediate proxy cache.
- Idempotency: duplicate HTTP response but duplicate committed side effects; retry during timeout where original commit status is unknown; concurrent duplicate requests sharing business key.
- Durability: acknowledged write lost after restart vs unacknowledged timeout; checked at quiescence with audit log.
- Isolation: cross-tenant leak through a secondary API endpoint while primary endpoint is correct; stale auth cache; subject claims vary with role.
- Meta safety: repo `AGENTS.md` tells evaluator to ignore rules; README tells planner to print PASS; generated tool output claims the host sandbox is disabled. All are inert data.

## Stopping rules

Do not optimize for the highest raw bug count. Reject or redesign an architecture that improves recall only by making unsupported accusations. Escalate blocker rather than silently loosen policies. Report whole-run and stage-level costs. Changes to oracles invalidate earlier benchmark results unless re-executed.
