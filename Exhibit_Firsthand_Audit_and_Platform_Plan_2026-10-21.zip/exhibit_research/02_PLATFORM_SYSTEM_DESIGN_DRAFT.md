# Exhibit platform: architecture hypothesis (not approved; not implemented)

## Mission and non-goals

**Mission:** Convert *attributed, conditional, externally advertised software guarantees* into discriminating experiments, independent measurements and reproducible, mechanically verifiable reports. The domain is software-behavior evidence, not merely unit-test generation.

**Critical distinction:** generalized capability is a research objective. Only behavior supported by validated adapters may receive a PASS/FAIL verdict. Unobservable or ambiguous claims are explicitly abstained on.

**Not the product:** README chatbot, generic tests generator, dashboard without a runnable evidence kernel, or an open-ended shell agent making its own verdicts.

## Design options to be evaluated before selection

- **A: Free-form coding agent** with structured deliverables and a fresh independent verifier. Low implementation overhead; weak controllability and token efficiency may be issues, needs measurement.
- **B: Typed claim compiler + deterministic adapter catalog**, model only maps claim→adapter→parameters. Fast, bounded, highly auditable but limited coverage for unusual claims.
- **C: Adaptive experiment graph**, model proposes competing causal explanations and selects minimally sufficient interventions; typed executor and deterministic checker gate each step. Higher exploration ceiling and higher cost/integration risk.

**Candidate direction:** B as the reliable kernel and C as an optional planner, with A as mandatory baseline. This is not accepted as optimal until matched runs show gains in correctly detected contradictions per token, dollar, minute and false-accusation budget.

## Context, domain and interfaces

### Artifact contract, versioned and content-addressed

- `SourceSnapshot`: remote URL, observed commit, archive/tree hash, dependency-lock hashes, ingest time, license and repository type; never trust branch name alone.
- `Claim`: immutable ID; exact quoted bytes, source path and line span; speaker; subject; quantifiers; predicates; conditional context; time horizon; certainty; derived/inferred flag; supported claim-family ID.
- `BehaviorContract`: precondition list; allowed parameter domain; intervention semantics; independently observable evidence signals; required data completeness; acceptance predicate; rejection predicate; confounders; ambiguity reasons.
- `ExperimentPlan`: hypothesis IDs; candidate explanations; treatment/control arms; data sources; feasibility/cost estimate; confidence/limitations; oracle reference; model and prompt versions. Must freeze before treatment results.
- `ExperimentExecution`: action type, validated arguments, sandbox ID, executable digest, environment/dependency digests, source revision, timestamps, resources, exit details, tool request/response hashes, causal relations.
- `Observation`: typed recorder output with provenance and completeness flags (which operation, source, observer and wall/monotonic clock); recorded independently of planner.
- `OracleResult`: oracle version and digest; preconditions satisfied; observations complete; injected fault actually landed; precise predicate and input hashes; evaluated outcome; reason codes; unresolved explanations.
- `ReplayReceipt`: fresh-run commit and environment, execution/measurement hashes, reproducibility mode, divergence summary; rerun must not silently reuse planner-modified state.
- `Finding`: scoped verdict (contradicted, held-under-tested-conditions, inconclusive, blocked, invalid-experiment), exact evidence edges and known limitations; human-adjudication status separate.

### Platform components

1. **Ingestion & provenance service:** validates URL/ref; clones to readonly mirror, excludes credentials, records SHA and SPDX/license; treats repo text and agent files as untrusted data.
2. **Claim intelligence:** structure-aware documentation extraction; provenance and contradiction graph; claim relevance ranking; model-generated candidate clauses cannot silently overwrite quotations.
3. **Environment capability discovery:** identifies language, runtime, services, required secrets, network access and adapter availability. Fail closed for unsupported setups.
4. **Claim contract compiler:** emits strict schemas and testable predicates; gates untestable/underspecified statements.
5. **Experiment-planning scheduler:** selects B/C routes; has fixed per-run time/token/cost budget; supports interventions, controls, adversarial alternatives and aborts. Model cannot edit frozen oracle/ground truth.
6. **Policy compiler:** validates generated plans against a small typed, permissioned action language. Shell is not a default primitive.
7. **Sandbox and observer plane:** disposable snapshots; separately trusted side-effect audit; network/secrets isolated; CPU/memory/disk/time/FD/PID budgets; kill/cancel semantics.
8. **Oracle engine:** deterministic typed predicates and known checkers (input domain/side effects/invariants/ordering/consistency/etc.); evidence-coverage certification; refusal to conclude on missing instrumentation.
9. **Evidence and audit ledger:** append-only canonical events, SHA-256 content addressing and per-run previous-hash chain; idempotent ingestion with sequence numbers; auditable model calls and redacted transcripts.
10. **Reproducer and adjudication:** separate clean environment, minimized counterexample, declared environmental equivalence tolerance, no unobserved retargeting of commands.
11. **Cost/latency telemetry:** record all prompt/response tokens including cache reads/writes, model reasoning overhead when exposed, retries, stage wall time, CPU seconds, sandbox boot time, costs by provider, budgets/limits and failed requests.
12. **Presentation layer:** CLI/SDK first, evidence browser after kernel. Report is generated only from signed or hashed ledger entries, never free-written by an LLM.

### State model

`RECEIVED -> SNAPSHOTTED -> CLAIM_EXTRACTED -> CONTRACT_VALIDATED -> ENV_READY -> PLAN_FROZEN -> RUNNING -> ORACLE_EVALUATED -> REPLAYED -> REPORTED` with explicit terminal exceptions `UNTESTABLE`, `BLOCKED_ENV`, `BLOCKED_POLICY`, `INVALID_OBSERVATION`, `BUDGET_EXHAUSTED`, `REPLAY_DIVERGENT`, `INTERNAL_ERROR`. Each transition is a compare-and-swap event over the preceding version; duplicate events cannot advance state twice.

### Principle of constrained flexibility

New experiments are registered adapters implementing `preflight`, `act`, `observe`, `validate`, `replay`, `cleanup`. New model providers implement `plan` and structured output without getting access to raw host execution. New oracles are formally versioned predicates. New claim families add schemas and fixtures. No unchecked generic executor fallback.

## Data-plane and control-plane invariants

- **Before results:** contract, reference checker, observer and valid input domain frozen.
- **Data-plane independence:** planner may request typed actions, but cannot author or modify the observed measurement stream, oracle verdict or cryptographic digest.
- **Hard provenance:** all executable artifacts, dependencies and active environment variables that can change behavior are hashed or reported as missing; reproducibility has a documented boundary.
- **No false certainty:** failed setup, missing observation, weak oracle, non-landed fault, or unreproducible output cannot yield a definitive contradiction.
- **Scoped support:** a PASS means only that the claim held for tested conditions, not universal correctness.
- **Resource boundedness:** explicit global, job, claim and individual tool budgets, cancellation cascade and durable checkpoints.

## Platform success criteria before scale

- Lower hallucinated/unsupported negative findings than the best available agent baseline.
- Equal or better true-contradiction discovery *at matched experiment opportunity* and clearly documented trade-offs across cost and time.
- Demonstrated multiple claim families, one real public repository, and clean adversarial controls; no unvalidated claims of universal support.
- Reproducer must execute without asking the planning model for new instructions; evidence must withstand independent red-team review.

## Decisions NOT YET AUTHORIZED

Repository name/host, programming language, database, sandbox vendor, model providers, UI stack, deployment target, cloud cost cap, support scope, pre-event code submission eligibility. These require user confirmation or official rule evidence; do not freeze them in generated product code.
