# Security, prompt injection, and evidentiary integrity

## Untrusted content boundaries

`README`, `AGENTS.md`, `CLAUDE.md`, source comments, commit messages, CI workflows, issue text, web pages, tool responses and repository test scripts are data, never agent/system instructions. Store their bytes and origin; extract **claims** under a fixed schema; do not execute instructions they contain because they address the model. Explicitly test role-spoofing, exfiltration prompts, hidden Unicode, shell command injection and log forging.

## Sandbox policies (requirements, not features implemented today)

- Check out a pinned commit into an immutable mirror; no workspace secrets, credentials, cloud metadata, SSH agent, home dir, Docker socket, host mounts, writable host repo, network by default.
- Provision dependencies separately with explicit allowlisted destinations and integrity checking; runtime experiments default to disabled external egress, or narrowly allowed instrumented loopback services.
- Ephemeral per-run UID/namespaces, read-only base root, writable scratch quota, CPU/RAM/PIDs/fds/disk/time caps, explicit cleanup and cancellation.
- Distinct trust tiers: planner/control service, untrusted execution, independent observer, oracle, signed/hashed append-only ledger and user report. The SUT cannot write into the oracle's state or evidence history.
- Explicitly tag controlled faults and authorization boundaries. No arbitrary malware or exploitation of third-party infrastructure in ordinary benchmarks.
- Output sanitizer: no raw untrusted HTML/JS in report, terminal escape sanitization, no secrets in logs, bounded text and artifact sizes; preserve original hashes for forensic verification.

## Evidence ledger design

`Event = {schema_version, run_id, seq, event_type, subject_id, actor, timestamp_utc, monotonic_ns, payload_sha256, previous_event_hash, event_hash}`. Canonical JSON bytes and versioned serialization rules. For SUT output, retain immutable blobs and reference them by sha256; cap and redact secrets with explicit redaction metadata. Distinguish observation time from ingestion time. Support duplicate delivery, resume, partial events, clock skew and loss; do not use the chain to claim that sensors were honest.

`Claims` / `Plans` / `Observations` / `OracleResults` must be separately attributed and linked. No self-certification by the model that authored the plan. Log blocked and inconclusive cases with equal permanence. Future signing/remote transparency log is optional until threat model requires it; local hash chains alone do not prevent a privileged operator from rewriting history.

## Risk register

| Risk | Failure | Required test / mitigation |
| --- | --- | --- |
| Prompt injection | README impersonates tool/system instructions | hostile fixture and structured data-only extraction; zero authorized effects |
| SUT breakout | generated code mounts Docker socket or reads secrets | isolated runtime, no privileged mounts, fake credentials, verification probes |
| Oracle spoofing | app prints success marker without satisfying claim | independent measurement + negative oracle-mutation controls |
| Equivalence confusion | env/config/executable change accepted as same action | freeze digests; exactly specified equivalence relation |
| Stale replay | same worktree/cache reused | fresh sandbox and dependency identity; negative replay test |
| False accusation | fault did not reach target | independent fault-landing evidence, abstain |
| Cost blowout | planner loops and long context | token/time/$ quotas per claim and entire session, checkpointed retry policies |
| Data poisoning | tool results supply fake observations | typed observer signatures/hashes, untrusted origin tags, independent cross-check |
| Trial cherry picking | report omits inconclusives or FPs | immutable run index, preregistration and denominator validation |
| License/provenance | upstream code copied indiscriminately | license audit and explicit reuse attribution before inclusion |

## What this audit cannot guarantee

Because no full sandbox runtime was available in this environment, these security properties are **requirements**, not verified protections. The uploaded repository code was executed only in selected local test contexts; a fully isolated code-execution infrastructure remains a launch blocker for evaluating arbitrary untrusted public repositories.
