from __future__ import annotations
import sys,json,hashlib,time,pathlib,statistics
root=pathlib.Path('/mnt/data/exhibit_audit/third_party')
sys.path.insert(0,str(root/'readme2demo-main'/'src'))
from readme2demo.types import CommandEntry,CommandLog,AgentResult
from readme2demo.distill import is_grounded
cases=[]
def test(name,recorded,proposed,expected_hazard):
 log=CommandLog(engine='claude-code',entries=[CommandEntry(cmd=recorded,exit_code=0,phase='demo')],result=AgentResult(outcome='success'))
 observed=is_grounded(proposed,log)
 cases.append(dict(test=name,recorded=recorded,proposed=proposed,grounding_accepts=observed,behavior_sensitive_difference=expected_hazard))
test('Exact replay', 'python service.py', 'python service.py', False)
test('Unseen new program','python service.py','python different.py', True)
test('Changed feature flag','CACHE_ENABLED=1 python service.py','CACHE_ENABLED=0 python service.py', True)
test('Changed endpoint selection','BACKEND_URL=http://a python service.py','BACKEND_URL=http://b python service.py', True)
test('Heredoc config body changed','cat >/tmp/config <<EOF\ncache=on\nEOF','cat >/tmp/config <<EOF\ncache=off\nEOF',True)
test('Different absolute executable','/trusted/bin/python app.py','/untrusted/bin/python app.py',True)
test('Independent unobserved cd','python service.py','cd /bad-dir', True)
# separate imports for other repo
sys.path.insert(0,str(root/'AgentProof-main'))
from agentproof.proof.tests import classify
from agentproof.engine.evidence import RunEvidence
proof=[]
for b,h in [(1,0),(0,0),(1,1),(0,1)]:
 def evidence(success,rev):
  return RunEvidence(revision=rev,command='pytest',cwd='/tmp',exit_code=0 if success else 1,duration_seconds=1,stdout_hash='sha',stderr_hash='',output_tail='',environment_fingerprint='identical')
 proof.append(dict(base_pass=bool(b),head_pass=bool(h),classification=classify('pytest',evidence(b,'base'),evidence(h,'head'))['status']))
from agentproof.proof.claims import normalize_claim
claim_cases={s:normalize_claim(s) for s in ['Repeated requests use Redis caching','idempotency keys are enforced','all tests pass','retries do not duplicate payments']}
result={'readme2demo_grounding':cases,'agentproof_base_head':proof,'agentproof_claim_normalization':claim_cases,'method':'Directly imported and executed untouched functions from uploaded archives; no model invocation, no end-to-end container replay; behavior_sensitive_difference denotes our designed semantic distinction, not an assertion of an exploitable bug.'}
p=pathlib.Path('/mnt/data/exhibit_audit/logs/api_probe_results.json');p.write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
