import concurrent.futures, subprocess, os, json, time, shlex, pathlib, re
root=pathlib.Path('/mnt/data/exhibit_audit/third_party')
logs=pathlib.Path('/mnt/data/exhibit_audit/logs');logs.mkdir(exist_ok=True)
runs=[
 ('agentproof_unit','AgentProof-main',['/opt/pyvenv/bin/python','-m','pytest','-q','tests/unit','tests/test_core.py','-p','no:cacheprovider']),
 ('readme2demo_suite','readme2demo-main',['/opt/pyvenv/bin/python','-m','pytest','-q','tests','-p','no:cacheprovider']),
 ('oss_fuzz_gen_agent_tests','oss-fuzz-gen-main',['/opt/pyvenv/bin/python','-m','pytest','-q','agent_tests','-p','no:cacheprovider']),
 ('agentic_pbt_syntax','agentic-pbt-main',['/opt/pyvenv/bin/python','-m','py_compile','run.py','scoring.py']),
]
def go(record):
 name,dir,argv=record; t=time.monotonic()
 env=os.environ.copy()
 for x in ['ANTHROPIC_API_KEY','OPENAI_API_KEY','GOOGLE_API_KEY','GEMINI_API_KEY','GITHUB_TOKEN','HF_TOKEN','NVIDIA_API_KEY','AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY']:env.pop(x,None)
 env.update({'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(root/dir)+(':'+str(root/dir/'src') if dir=='readme2demo-main' else ''),'HOME':'/mnt/data/exhibit_audit/tmp_home','PIP_NO_INDEX':'1','NO_PROXY':'*'})
 pathlib.Path(env['HOME']).mkdir(exist_ok=True)
 try:
  p=subprocess.run(argv,cwd=root/dir,env=env,capture_output=True,text=True,timeout=80)
  result={'name':name,'command':shlex.join(argv),'returncode':p.returncode,'elapsed_seconds':round(time.monotonic()-t,3),'stdout_tail':p.stdout[-5000:],'stderr_tail':p.stderr[-1800:],'timeout':False}
 except subprocess.TimeoutExpired as e:
  result={'name':name,'command':shlex.join(argv),'returncode':None,'elapsed_seconds':round(time.monotonic()-t,3),'stdout_tail':str(e.stdout)[-2000:],'stderr_tail':str(e.stderr)[-1200:],'timeout':True}
 (logs/(name+'.json')).write_text(json.dumps(result,indent=2))
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 out=list(ex.map(go,runs))
(logs/'test_summary.json').write_text(json.dumps(out,indent=2))
for x in out:
 print(json.dumps({k:v for k,v in x.items() if k not in ('stdout_tail','stderr_tail')}));print('STDOUT:',x['stdout_tail'][-1100:]);print('STDERR:',x['stderr_tail'][-600:])
